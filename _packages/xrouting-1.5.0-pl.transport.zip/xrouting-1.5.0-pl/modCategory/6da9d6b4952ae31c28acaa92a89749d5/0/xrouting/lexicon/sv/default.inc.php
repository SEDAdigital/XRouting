<?php
/**
 * Default Lexicon Entries for XRouting
 *
 * @package xrouting
 * @subpackage lexicon
 */
$_lang['xrouting'] = 'XRouting';
