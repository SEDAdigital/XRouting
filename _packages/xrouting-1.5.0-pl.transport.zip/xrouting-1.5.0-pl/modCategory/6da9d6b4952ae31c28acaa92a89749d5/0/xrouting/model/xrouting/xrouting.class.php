<?php
/**
 * xrouting
 *
 * Copyright 2014-2023 by Christian Seel - <office@seda.digital>
 *
 * @package xrouting
 * @subpackage classfile
 */

require_once dirname(__DIR__, 2) . '/vendor/autoload.php';

/**
 * Class XRouting
 */
class XRouting extends \SEDAdigital\XRouting\XRouting
{
}
