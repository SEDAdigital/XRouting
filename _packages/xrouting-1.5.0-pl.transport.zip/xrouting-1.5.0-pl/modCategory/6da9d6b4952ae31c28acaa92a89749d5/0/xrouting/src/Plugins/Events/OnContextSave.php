<?php
/**
 * @package xrouting
 * @subpackage plugin
 */

namespace SEDAdigital\XRouting\Plugins\Events;

class OnContextSave extends OnSiteRefresh
{
}
