<?php
/**
 * @package xrouting
 * @subpackage plugin
 */

namespace SEDAdigital\XRouting\Plugins\Events;

class OnContextRemove extends OnSiteRefresh
{
}
