<?php
/**
 * Default Lexicon Entries for SmartRouting
 *
 * @package smartrouting
 * @subpackage lexicon
 */
$_lang['smartrouting'] = 'SmartRouting';
