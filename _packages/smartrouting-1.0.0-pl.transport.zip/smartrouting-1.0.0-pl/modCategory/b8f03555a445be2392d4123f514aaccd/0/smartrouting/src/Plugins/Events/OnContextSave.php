<?php
/**
 * @package smartrouting
 * @subpackage plugin
 */

namespace TreehillStudio\SmartRouting\Plugins\Events;

class OnContextSave extends OnSiteRefresh
{
}
